import sqlite3
from bottle import route, run, request, response, template

@route('/tech_menu')
def tech_menu():
    return template('tech_menu')

@route('/status')
def status():
    return template('status')

@route('/', method = "GET") #initial login page
def index():
    return template('login_page')

@route('/login', method = "POST") #login page after clicking submit button
def login():
    user = request.forms.get("username") #get username
    
    conn = sqlite3.connect("travel_expenses.db")
    cur = conn.cursor()
    sql = "SELECT * FROM members WHERE username = ?"
    
    cur.execute(sql, (user,))
    result = cur.fetchone()
    cur.close()
    print(result)
    
    if (result):
        return template('tech_menu')
    else:
        m = {'msg': 'login failed'}
        return template('status', m)

@route('/trips_form')
def trips_form():
    return template('trips_form')

@route('/add_trip')
def trips_form():
    return template('add_trip')

@route('/show_trips', method = ["GET", "POST"])
def table():
    if request.method == 'POST':
        user = request.forms.get("username")
        print(user)
        print('test')
        conn = sqlite3.connect("travel_expenses.db")
        cur = conn.cursor()
        sql = "SELECT * FROM trips WHERE username = ? "
        cur.execute(sql, (user, ))
        data = cur.fetchall()
        cur.close()
        output = template('show_trips', rows=data)
        print(data)
        return output
    # else:

    
@route('/add_trip', method='POST')
def addTrip():
        user = request.forms.get('user')
        date = request.forms.get('date')
        dest = request.forms.get('dest')
        miles =request.forms.get('miles')
        gallons = request.forms.get('gallons')
        print(user, date, miles,gallons)
        
        try:
            conn = sqlite3.connect("travel_expenses.db")
            cur = conn.cursor()
            
            data = (None, user, date, dest, miles, gallons)
            
            sql = "INSERT INTO trips VALUES (?, ?, ?, ?, ?, ?)"
            
            cur.execute(sql,data)
            conn.commit()
            cur.close
            
            m = {'msg': 'insert trip successful'}
            return template('add_trip', m)
        except:
            m = {'msg': 'insert trip was not successful'}
            return template('status', m)


run(host= 'localhost',port=8081, reload=True, debug=True)