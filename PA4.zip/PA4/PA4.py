
# Program Assignment 4
# Programmer: Seth Ingram
# Date: 11/6/21
# Purpose: We will make a desktop app using wxPython that queries a web service named finnhub.io for data. 
# We will combine this data with some of the data in our tech_stocks database and display using wx python
# finhub api: c63fleiad3id43aa6ql0 


    #loop thru the rows.
    # get the stock symbol for the stock in this row
    # concatenate the request to the web service for that stock
    # get the current price for the stock
    # calculate profit or loss
    # append info to the list control

#imports
import sqlite3
import requests
import wx
import datetime

from wx.core import ALIGN_CENTER, BORDER, EXPAND, LIST_AUTOSIZE, LIST_AUTOSIZE_USEHEADER, STB_DEFAULT_STYLE, Width


#finhub.io data collection
api = 'c63fleiad3id43aa6ql0'


class DataList(wx.Frame):
    def __init__(self, parent, id, title):
        wx.Frame.__init__(self, parent, id, title, size=(700, 580))        
        panel = wx.Panel(self, -1)
    
            # ------------------  top row widgets  -------------------------------
        self.date = wx.StaticText(panel, -1, "Today's Date", style= wx.ALIGN_CENTER)

        # ----------------------------- date widget  ------------------------------------
        self.total = wx.StaticText(panel, -1, "Total", style=wx.ALIGN_CENTER)  


        # ------------------  list control --------------------------------
        self.list = wx.ListCtrl(panel, -1, style=wx.LC_REPORT, size=(680, 300))
        
        font1 = wx.Font(10, wx.FONTFAMILY_TELETYPE, wx.NORMAL, wx.NORMAL, False, u'Consolas')
        self.list.SetFont(font1)  # use a monospace font
        
        self.list.InsertColumn(0, 'Company', width=160)
        self.list.InsertColumn(1, 'Symbol') 
        self.list.InsertColumn(2, 'Purchase Price', width=120) 
        self.list.InsertColumn(3, 'Current Price', width=120)
        self.list.InsertColumn(4, 'Shares')
        self.list.InsertColumn(5, 'Gain/Loss', width=91)



        # -----------------------  buttons  ---------------------------
        display = wx.Button(panel, -1, 'Display', size=(-1, 30))  # setup buttons 
        cancel = wx.Button(panel, -1, 'Cancel', size=(-1, 30)) 
        display.Bind(wx.EVT_BUTTON, self.OnDisplay )  # bind buttons 2 event handlers 
        cancel.Bind(wx.EVT_BUTTON, self.OnCancel) 

        # ------------------------------- add widgets to sizers -------------------------
        



        # add buttons to btnRowHsizer horizontal box sizer
        btnRowHsizer = wx.BoxSizer(wx.HORIZONTAL)
        btnRowHsizer.Add(display, 0, wx.ALIGN_CENTER | wx.ALL, border=15)
        btnRowHsizer.Add(cancel, 0, wx.ALIGN_CENTER | wx.ALL, border=15)

        # add everything to mainBoxVsizer vertical box sizer
        mainBoxVsizer = wx.BoxSizer(wx.VERTICAL)
        mainBoxVsizer.Add(self.date, 0, wx.ALIGN_CENTER | wx.TOP, border=15)  # date label
        mainBoxVsizer.Add(self.total, 0, wx.ALIGN_CENTER | wx.BOTTOM, border=15)
        mainBoxVsizer.Add(self.list, 0, wx.ALIGN_CENTER | wx.ALL, border=15)  # add list ctrl & buttons to sizers
        mainBoxVsizer.Add(btnRowHsizer, 0, wx.ALIGN_CENTER | wx.ALL, border=15)
        
        panel.SetSizer(mainBoxVsizer)

        self.cbValue = None 
        self.cbCount = 0

        self.Centre()     # center the window

    def getAllData(self):   # helper function, displays whole table
        self.list.DeleteAllItems()    # empty the list control
        #updatea the date/time
        x = datetime.datetime.now() # date and time
        date = x.strftime("%A %B %d, %Y : %H:%M")
        self.date.SetLabel(date)
        
        #populate table
        con = sqlite3.connect('tech_stocks.db')  # connect to db
        cur = con.cursor()
        cur.execute('SELECT company, symbol, purchase_price, shares FROM dow_stocks')
        results = cur.fetchall()
        print(results)
        for row in results:
            url = 'https://finnhub.io/api/v1/quote?symbol=' + row[1] + '&token=' + api
            req = requests.get(url)
            data = req.json()
            print(data['c'])
            current_price = data["c"]
            gain_loss = (row[3] * current_price) - (row[3] * row[2])
            gain_loss = round(gain_loss, 2)
            self.list.Append((row[0], row[1], row[2], data["c"],row[3], gain_loss))
        cur.close()
        con.close()

    def OnDisplay(self, event):
        try:
            self.getAllData()      # display whole table
        except sqlite3.Error as error:
            dlg = wx.MessageDialog(self, str(error), 'Error occured')
            dlg.ShowModal()       # display error message

    def OnCancel(self, event):
        self.Close()  # exit program


app = wx.App()
dl = DataList(None, -1, 'Insert Into List Control')
dl.Show()
app.MainLoop()